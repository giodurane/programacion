/*
 * t1enteros.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * Un carácter suelto como una letra o un signo de puntuación se puede
 * almacenar en una variable de tipo char. El carácter debe ir
 * entrecomillado utilizando las comillas simples (‘).
 *
 * 'a' caracter suelto
 * "a" cadena de caracteres
 */


public class t2usoDeChar {

	public static void main (String[] args) {
  char letra1 = 'a';
  char letra2 = 'b';
  char letra3 = 'c';
  char letra4 = 'd';

  System.out.println("letra1 "+letra1);
  System.out.println("letra3 "+letra3);
  System.out.println("todas las letras juntas " + letra1 + letra2 + letra3 + letra4);
	}
}

