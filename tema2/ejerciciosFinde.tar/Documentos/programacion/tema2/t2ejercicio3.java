/*
 * t2ejercicio4.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * Ejercicio 3
 * -----------
 * Realiza un conversor de euros a pesetas. La cantidad en euros que se quiere
 * convertir deberá estar almacenada en una variable.
 */


public class t2ejercicio3 {

	public static void main (String[] args) {

  String nombre = "Mario Giovanny Duran Eyzaguirre";
  String direcc = "Av. Pinos del mar, 45";
  long mov = 6123456789L;


  System.out.println("Vamos a ver tu nombre completo: "+nombre);
  System.out.println("Vamos a ver tu dirección: "+direcc);
  System.out.println("Vamos a ver tu # de móvil: "+mov);
	}
}

