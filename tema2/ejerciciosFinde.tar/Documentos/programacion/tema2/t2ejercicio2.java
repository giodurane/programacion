/*
 * t2asignacionValoresVariables.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * Ejercicio 2
 * -----------
 * Crea la variable nombre y asígnale tu nombre completo. Muestra su valor
 * por pantalla de tal forma que el resultado del programa sea el mismo que
 * en el ejercicio 1 del capítulo 1.

 */


public class t2ejercicio2 {

	public static void main (String[] args) {

  String nombre = "Mario Giovanny Duran Eyzaguirre";


  System.out.println("Vamos a ver tu nombre completo: "+nombre);
	}
}

