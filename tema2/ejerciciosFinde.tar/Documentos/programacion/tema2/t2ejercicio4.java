/*
 * t2ejercicio4.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * Ejercicio 3
 * -----------
 * Realiza un conversor de euros a pesetas. La cantidad en euros que se quiere
 * convertir deberá estar almacenada en una variable.
 */


public class t2ejercicio4 {

	public static void main (String[] args) {
  int euros = 1;
  int pesetas = 166;

  int eu_pt =  a (double) / b (double);


  System.out.println("Vamos a convertir Euros en Pesetas: "+nombre);


	}
}

