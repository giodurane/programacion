/*
 * t1enteros.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * la variable double me permite utilizar decimales (coma flotante) sin
 * restrinciones, a diferencia de float, que solo representa enteros como
 * si llevasen decimales.
 *
 * DOUBLE ES MAS MEHÓ
 */


public class t2float {

	public static void main (String[] args) {
  float x;
  float y;

  x = 7;
  y = 10;

  System.out.println("El valor actual de mi variable x es "+x);
  System.out.println("El valor actual de mi variable y es "+y);
	}
}

