/*
 * t2asignacionValoresVariables.java
 *
 * Copyright 2020 Giovanny Duran <mario.duran.alu@iescampanillas.com>
 *
 * Es importante recalcar que una asignación no es una ecuación. En el
 * lado izquierdo debemos tener únicamente un nombre de variable
 *
 */


public class t2asignacionValoresVariables {

	public static void main (String[] args) {
  int x = 10;
  int y = 144;

  int suma = x + y;
  System.out.println("Vamos a ver el valor de X: "+ x);
  System.out.println("Vamos a ver el valor de X: "+ y);
  System.out.println("Vamos a sumar los valores X e Y: "+ suma);

  int mult = x * y;
  System.out.println("multiplicamos los valores de X e Y: "+mult);
	}
}

