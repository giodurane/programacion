/*
 * Enero18_ej1.java
 * 
 * Copyright 2021 Mario Giovanny Duran Eyzaguirre <mario.duran.alu@iescampanillas.com>
 * 
 * Implemente una función que reciba un array de enteros como argumento.
 * Deberá informar de su tamaño (del número de elementos que tiene), 
 * y deberá presentarla por pantalla debidamente formateada y "con los
 * adornos correspondientes" a una buena presentación. 
 */

//package Enero;
public class Enero18ej1 {
	
	public static String ejercicio(int []x) {
  String funcion = "uno, dos, tres";
  
  for (int i=0; i>0; i++) {
    funcion = (""+x[i]);
  }
  return funcion;
  /*System.out.print(x.leght);
  System.out.printf("%d\n"x)*/
  }
}


