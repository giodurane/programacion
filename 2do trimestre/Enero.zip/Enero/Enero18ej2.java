/*
 * Enero18_ej2.java
 * 
 * Copyright 2021 Mario Giovanny Duran Eyzaguirre <mario.duran.alu@iescampanillas.com>
 * 
 * Implemente una función que reciba como argumentos un array de enteros,
 * y otros dos enteros, que serán los extremos de un rango entre los
 * que la función elegirá valores aleatorios (ambos incluidos) y
 * rellenará el array pasado como argumento. Esta función no tiene
 * que devolver, como función, nada (ya realiza cambios a través del
 * argumento del array de enteros, el cual va pasado por referencia)
 * 
 */

//package Enero;
public class Enero18ej2 {
	
	public static void main (String[] args) {
		String[] x;
    int a;
    int b;
	}
}

